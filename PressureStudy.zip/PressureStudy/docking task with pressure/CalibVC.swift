
import UIKit

class CalibVC: UIViewController {
    
    private var _maxForcePerTouch: CGFloat = 0.0
    private var _maxforceSet:[CGFloat] = []
    private var _lightMean: CGFloat = 0.0
    private var _hardMean: CGFloat = 0.0
    
    private var x:[CGFloat] = [100, 500, 200, 300, 450]
    private var y:[CGFloat] = [100, 250, 150, 200, 100]
    private var contain = false
    
    private var counter = 0

    
    @IBOutlet weak var circleView: Circle!
    
    @IBOutlet weak var topText: UILabel!
    @IBOutlet weak var subText: UILabel!
    
    @IBOutlet weak var passButton: UIButton!
    @IBOutlet weak var resetButton: UIButton!
    @IBAction func resetButtonUpInside(_ sender: Any) {
        counter = 0
        _maxForcePerTouch = 0.0
        _maxforceSet = []
        _lightMean = 0.0
        _hardMean = 0.0
        topText.text = "Please touch the circle with a small force."
        subText.text = "\(5-counter) times left."
        passButton.setTitle("PASS", for: .normal)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        topText.text = "Please touch the circle with a small force."
        subText.text = "\(5-counter) times left."
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        showAlertButtonTapped("Please touch the circle with a light force.")
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if counter >= 10 {return}
        contain = circleView.containsLocation((touches.first?.location(in: circleView))!)
        if !contain {return}
        switch interMode {
        case InteractionMode.BinaryPressure:
            _maxForcePerTouch = (touches.first?.force)!
            break
        default:
            break
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if counter >= 10 {return}
        if !contain {return}

        switch interMode {
        case InteractionMode.BinaryPressure:
            if (touches.first?.force)! > _maxForcePerTouch {
                _maxForcePerTouch = (touches.first?.force)!
            }
            break
        default:
            break
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if counter >= 10 {return}
        if !contain {return}

        _maxforceSet.append(_maxForcePerTouch)
        counter += 1
        var index = 0
        if counter>=5 {index=10-counter} else {index=5-counter}
        subText.text = "\(index) times left."
        
        if counter == 5 {
            print(_maxforceSet)
            var forceSum: CGFloat = 0.0
            for i in 0..._maxforceSet.count-1 {
                forceSum += _maxforceSet[i]
            }
            _lightMean = forceSum/CGFloat(_maxforceSet.count)
            _maxforceSet = []
            topText.text = "Please touch the circle with a heavy force."
            showAlertButtonTapped("Now prepare to touch hardly.")
        }
        
        if counter == 10 {
            print(_maxforceSet)
            var forceSum: CGFloat = 0.0
            for i in 0..._maxforceSet.count-1 {
                forceSum += _maxforceSet[i]
            }
            _hardMean = forceSum/CGFloat(_maxforceSet.count)
            topText.text = "Trainning finished."
            print(_lightMean)
            print(_hardMean)
            passButton.setTitle("FINISH", for: .normal)
            switch interMode {
            case InteractionMode.BinaryPressure:
                if _lightMean < _hardMean - 1 {
                    forceThreshold = (_lightMean + _hardMean)/2
                    subText.text = "Force threshold is \(forceThreshold), max force is \(20.0/3.0)."
                }else{
                    subText.text = "Light and hard touch non distinguishable, use default setting."
                }
                break
            default:
                break
            }
        }
        circleView.centerX = x[counter%5]
        circleView.centerY = y[counter%5]
    }
    
    func showAlertButtonTapped(_ text: String) {
        
        // create the alert
        let alert = UIAlertController(title: text, message: "", preferredStyle: UIAlertControllerStyle.alert)
        
        // add an action (button)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        
        // show the alert
        self.present(alert, animated: true, completion: nil)
    }
}
