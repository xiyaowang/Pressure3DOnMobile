
import UIKit

class Circle: UIView {
    var centerX:CGFloat = 100.0 { didSet { setNeedsDisplay() } }
    var centerY:CGFloat = 100.0 { didSet { setNeedsDisplay() } }
    var radius:CGFloat = 30.0 { didSet { setNeedsDisplay() } }
    var lineWidth:CGFloat = 2.0 { didSet { setNeedsDisplay() } }
    
    private func getCicrle() -> UIBezierPath{
        let circlePath = UIBezierPath(arcCenter: CGPoint(x:self.centerX,y:self.centerY),
                                      radius: self.radius,
                                      startAngle: 0.0,
                                      endAngle:CGFloat(M_PI*2),
                                      clockwise: true)
        circlePath.lineWidth = self.lineWidth
        return circlePath
    }
    
    func containsLocation(_ point: CGPoint) -> Bool{
        return getCicrle().contains(point)
    }
    
    
    override func draw(_ rect: CGRect){
        UIColor.black.set()
        let c = getCicrle()
        c.stroke()
    }
}
