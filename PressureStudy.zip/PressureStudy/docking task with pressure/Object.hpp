

#ifndef Object_hpp
#define Object_hpp

#include "global.h"
#include "loader_obj.h"
#include "mesh.h"


static const int SCREEN_WIDTH = 1334, SCREEN_HEIGHT = 750;
static const double aspect = double(SCREEN_WIDTH)/SCREEN_HEIGHT;

class Object{
public:
    Object(const std::string& filename);
    ~Object();
    
    void rebind();
    void render();
    
    void setObj(double xTrans,double yTrans, double zTrans, double x, double y, double z, double w);
    void setTarget(double xTrans,double yTrans, double zTrans, double x, double y, double z, double w);
    
    void rotateX(double x, double y, double z, double w);
    void rotateY(double x, double y, double z, double w);
    void rotateZ(double var);
    void scale(double var);
    void translateX(double var);
    void translateY(double var);
    void translateZ(double var);

    void reset();
    void recordView();
    void recallView();
    

    
    
private:
    
    MeshPtr data;
    MeshPtr target;
    
    Matrix4 projMatrix;
    Matrix4 modelViewMatrix;
    Vector3 center;
    float zooming;
    
    Matrix4 pProjMatrix;
    Matrix4 pModelViewMatrix;
    Vector3 pCenter;
    float pzooming;

    
    Matrix4 tprojMatrix;
    Matrix4 tmodelViewMatrix;
    Vector3 tcenter;
    float zoomingFactor = 3.0;

 
};









#endif /* Object_hpp */
