

import GLKit
import AudioToolbox

class GLVC: GLKViewController, UIGestureRecognizerDelegate {

    private let height = UIScreen.main.bounds.height
    private let width = UIScreen.main.bounds.width
    private let screenScale = UIScreen.main.scale
    private var firstShow = true

    
    var isLightTouch = TouchMode.no
    var timer: Timer = Timer()
    var tInterval = 1.0
    
    var rBackground: GLfloat = 0.0
    var gBackground: GLfloat = 0.0
    var bBackground: GLfloat = 0.0
    
    
    private var _gestureDetected = false
    private var previousRotateZ : Double = 0.0
    private var previousScale : Double = 1.0
    private var previousPanposX1 : Double = 1.0
    private var previousPanposX2 : Double = 1.0
    private var previousPanposY1 : Double = 1.0
    private var previousPanposY2 : Double = 1.0
    
    private var startTime:Date? = nil
    
    private var cppObject = UnsafeMutableRawPointer(mutating: createObj(UnsafeMutablePointer<Int8>(mutating: Bundle.main.path(forResource: "bunny", ofType: "obj")!)
))
    
    @IBOutlet weak var text1: UILabel!
    @IBOutlet weak var text2: UILabel!
    @IBOutlet weak var text3: UILabel!
    @IBOutlet weak var trialButton: UIButton!
    @IBAction func trialButtonUpInside(_ sender: Any) { next() }
    
    func next(){
        if isTrainning {
            objSetTarget(cppObject, target_train[train_index][0], target_train[train_index][1], target_train[train_index][2], target_train[train_index][3], target_train[train_index][4], target_train[train_index][5], target_train[train_index][6])
            objSetObj(cppObject, obj_train[0], obj_train[1], obj_train[2], obj_train[3], obj_train[4], obj_train[5], obj_train[6])
            train_index = (train_index+1)%3
            gainFactor = trial_gainFactor[train_index]
            text3.text = "Gain factor: \(gainFactor)"
            log_reset(0)
        }else{
            if trial_number != 0  {
                let time = Date().timeIntervalSince(startTime!) - time_stop
                trial_finaldata.append("\(time),\(compute_distance()),\(compute_angle())\n")
                saveFile()
            }
            if trial_number == trial_max && interMode == firstMode {
                isTrainning = true
                text1.text = "Trainning phase."
                interMode = secondMode
                text2.text = String(describing: interMode)
                train_index = 0
                gainFactor = trial_gainFactor[train_index]
                text3.text = "Gain factor: \(gainFactor)"
                trial_number = 0
                trial_finaldata.append(String(describing: interMode) + "\n")
                trial_finaldata.append("Time,Distance,Angle\n")
                showAlertButtonTapped("Trainning phase.", "You have unlimited time to try this technique, press next button on the left down corner for next trial, gain factor will change. When you're ready for real tasks, please let the examiner know.")
                return
            }
            if trial_number == trial_max && interMode != firstMode {
                saveFinal()
                manipIsActive = false
                showAlertButtonTapped("Finished.", "You have finished all tasks required, thank you for your participation.")
                return
            }
            let i = trial_list[trial_number%trial_gain]
            objSetTarget(cppObject, target_data[i][0], target_data[i][1], target_data[i][2], target_data[i][3], target_data[i][4], target_data[i][5], target_data[i][6])
            objSetObj(cppObject, obj_data[i][0], obj_data[i][1], obj_data[i][2], obj_data[i][3], obj_data[i][4], obj_data[i][5], obj_data[i][6])
            log_reset(i);
            trial_number += 1
            text1.text = "Trial number \(trial_number)."
            if trial_number <= trial_gain {
                gainFactor = trial_gainFactor[0]
            }else if trial_number <= trial_gain*2 {
                gainFactor = trial_gainFactor[1]
            }else {
                gainFactor = trial_gainFactor[2]
            }
            text3.text = "Gain factor: \(gainFactor)"
            
        }
        startTime = Date()
        time_stop = 0.0

    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        manipIsActive = true

        setupGesrures();
        setupGL();
        print(forceThreshold)

        selectSetting(Int(USERID)!)
        print(firstMode)
        print(trial_gainFactor)
        print(trial_list)
        
        startTime = Date()
        /*
        isTrainning = false
        interMode = secondMode
        trial_number = 29
        forceThreshold = 3.38958333249514*/
 
        interMode = firstMode
        
        objSetTarget(cppObject, target_train[train_index][0], target_train[train_index][1], target_train[train_index][2], target_train[train_index][3], target_train[train_index][4], target_train[train_index][5], target_train[train_index][6])
        objSetObj(cppObject, obj_train[0], obj_train[1], obj_train[2], obj_train[3], obj_train[4], obj_train[5], obj_train[6])
        log_reset(0)
        trial_finaldata = "User ID,\(USERID) \n"
        trial_finaldata.append(String(describing: interMode) + "\n")
        trial_finaldata.append("Time,Distance,Angle\n")
        
        
        text1.text = "Training phase."
        text2.text = String(describing: interMode)
        gainFactor = trial_gainFactor[0]
        text3.text = "Gain factor: \(gainFactor)"

        objRebind(cppObject)

    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if firstShow {
            showAlertButtonTapped("Trainning phase.", "You have unlimited time to try this technique, press next button on the left down corner for next trial, gain factor will change. When you're ready for real tasks, please let the examiner know.")
            firstShow = false
        }
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func setupGesrures(){
        let pinchGesture = ForcePinchGestureRecognizer(target:self, action:#selector(self.pinchDetected))
        pinchGesture.delegate = self
        self.view.addGestureRecognizer(pinchGesture)
        
        
        let rotateGesture = ForceRotationGestureRecognizer(target: self,action:#selector(self.rotationDetected(_:)))
        rotateGesture.delegate = self
        self.view.addGestureRecognizer(rotateGesture)
        
        let panGestureTwo = ForcePanGestureRecognizer(target: self, action:#selector(self.panTwoDetected(_:)))
        panGestureTwo.minimumNumberOfTouches = 2;
        panGestureTwo.maximumNumberOfTouches = 2;
        panGestureTwo.delegate = self
        self.view.addGestureRecognizer(panGestureTwo)
    }
    
    func setupGL(){
        let glkView: GLKView = view as! GLKView
        glkView.context = EAGLContext(api: .openGLES3)
        glkView.drawableColorFormat = .RGBA8888
        glkView.drawableDepthFormat = .format24
        EAGLContext.setCurrent(glkView.context)
        
        glClearColor(rBackground, gBackground, bBackground, 0)
        glClearDepthf(1.0)
        
        glEnable(GLenum(GL_SCISSOR_TEST))
        glEnable(GLenum(GL_DEPTH_TEST));
        glDepthFunc(GLenum(GL_LESS));
        
    }

    
    func update(){
        
        switch isLightTouch {
        case TouchMode.no:
            rBackground = 0.0
            gBackground = 0.0
            bBackground = 0.0
            break
        case TouchMode.light:
            rBackground = 0.3
            gBackground = 0.3
            bBackground = 0.3
            break
        case TouchMode.oneHard:
            rBackground = 0.6
            gBackground = 0.6
            bBackground = 0.6
            break
        default:
            break
        }
    }
    
    override func glkView(_ view: GLKView, drawIn rect: CGRect) {
        
        glViewport(0, 0, GLsizei(width*screenScale), GLsizei(height*screenScale))
        glScissor(0, 0, GLsizei(width*screenScale), GLsizei(height*screenScale))

        glClearColor(rBackground, gBackground, bBackground, 1);
        glClear(GLbitfield(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT))
        
        objRender(cppObject)

    }
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
            return true;
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if !manipIsActive { return }
        if touches.count >= 3 {
            performSegue(withIdentifier: "MainToMenu", sender: self)
            isLightTouch = TouchMode.no
            return
        }
        if isLightTouch == TouchMode.oneHard && timer.isValid && (event?.allTouches?.count)! == 2 {
            objRecall(cppObject)
            let time = Date().timeIntervalSince(startTime!)
            log_recall(time - time_stop)
            timer.invalidate()
        }
        if isLightTouch == TouchMode.no {
            isLightTouch = TouchMode.light
        }
        
        
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if !manipIsActive { return }
        if _gestureDetected { return }
        if touches.count >= 3 {
            performSegue(withIdentifier: "MainToMenu", sender: self)
            isLightTouch = TouchMode.no
            return
        }
        switch interMode {
        case InteractionMode.noPressure:
            if touches.count == 1{
                let touche = touches.first!
                let location = touche.location(in: self.view)
                let previousLocation = touche.previousLocation(in: self.view)

                let dx = (Double)(location.x-previousLocation.x)
                let dy = (Double)(location.y-previousLocation.y)
                if(dx > transThres || dx < -transThres) {
                    //let angle = constraintYAngle(Double(location.x), Double(previousLocation.x),Double(width*screenScale))
                    let angle = rotYAngle(-gainFactor*dx, Double(width))
                    cppRotateY(cppObject,angle[0],angle[1],angle[2],angle[3])
                    let time = Date().timeIntervalSince(startTime!)
                    log_rotateY(time-time_stop, angle)
                }
                if(dy > transThres || dy < -transThres) {
                    //let angle = constraintXAngle(Double(location.y), Double(previousLocation.y),Double(height*screenScale))
                    let angle = rotXAngle(gainFactor*dy, Double(height))
                    cppRotateX(cppObject, angle[0],angle[1],angle[2],angle[3])
                    let time = Date().timeIntervalSince(startTime!)
                    log_rotateX(time-time_stop, angle)
                }
            }
            break
        case InteractionMode.BinaryPressure:
            //if #available(iOS 9.0, *) {
            if traitCollection.forceTouchCapability == UIForceTouchCapability.available {
                if touches.count == 1{
                    let touch = touches.first!
                    let location = touch.location(in: self.view)
                    let previousLocation = touch.previousLocation(in: self.view)
                    let dx = (Double)(location.x-previousLocation.x)
                    let dy = (Double)(location.y-previousLocation.y)
                    if (isLightTouch == TouchMode.light && touch.force >= forceThreshold) {
                        isLightTouch = TouchMode.oneHard
                        //AudioServicesPlayAlertSound(SystemSoundID(kSystemSoundID_Vibrate))
                        AudioServicesPlaySystemSound(1520)
                        
                        timer = Timer.scheduledTimer(timeInterval: tInterval, target: self, selector: #selector(self.counter), userInfo: nil, repeats: false)
                        objRecord(cppObject)
                        let time = Date().timeIntervalSince(startTime!)
                        log_record(time-time_stop)
                    }
                    
                    if isLightTouch == TouchMode.light {
                        if dx > transThres || dx < -transThres {
                            //let angle = constraintYAngle(Double(location.x), Double(previousLocation.x),Double(width*screenScale))
                            let angle = rotYAngle(-gainFactor*dx, Double(width))
                            cppRotateY(cppObject, angle[0],angle[1],angle[2],angle[3])
                            let time = Date().timeIntervalSince(startTime!)
                            log_rotateY(time-time_stop, angle)
                        }
                        if dy > transThres || dy < -transThres {
                            //let angle = constraintXAngle(Double(location.y), Double(previousLocation.y),Double(height*screenScale))
                            let angle = rotXAngle(gainFactor*dy, Double(height))
                            cppRotateX(cppObject, angle[0],angle[1],angle[2],angle[3])
                            let time = Date().timeIntervalSince(startTime!)
                            log_rotateX(time-time_stop, angle)
                        }
                    }else if isLightTouch == TouchMode.oneHard {
                        if(dx > transThres || dx < -transThres) {
                            cppTranslateX(cppObject,gainFactor*transXFactor*dx)
                            let time = Date().timeIntervalSince(startTime!)
                            log_transX(time-time_stop, gainFactor*transXFactor*dx)

                        }
                        if(dy > transThres || dy < -transThres) {
                            cppTranslateY(cppObject,gainFactor*transYFactor*dy)
                            let time = Date().timeIntervalSince(startTime!)
                            log_transY(time-time_stop, gainFactor*transYFactor*dy)
                        }
                    }
                }else if touches.count == 2 {
                    let first = (touches as NSSet).allObjects[0] as! UITouch
                    let second = (touches as NSSet).allObjects[1] as! UITouch
                    if !_gestureDetected && (isLightTouch == TouchMode.light && (first.force >= forceThreshold || second.force >= forceThreshold )) {
                        //isLightTouch = TouchMode.twohards
                        isLightTouch = TouchMode.oneHard
                        //AudioServicesPlayAlertSound(SystemSoundID(kSystemSoundID_Vibrate))
                        AudioServicesPlaySystemSound(1520)
                    }
                }            }
            // }
            break
        default:
            break
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if !manipIsActive { return }
        if timer.isValid {
            timer.invalidate()
        }
        
        if touches.count == (event?.allTouches?.count)! {
            isLightTouch = TouchMode.no
            _gestureDetected = false
        }
        
    }
    
    
    
    @IBAction func pinchDetected(_ sender: ForcePinchGestureRecognizer) {
        if !manipIsActive { return }

        switch interMode {
        case InteractionMode.noPressure:
            switch sender.state {
            case UIGestureRecognizerState.began:
                if sender.numberOfTouches != 2 {break}
                _gestureDetected = true
                previousScale = 1.0
                break
            case UIGestureRecognizerState.ended:
                _gestureDetected = false
                break
            default:
                if sender.numberOfTouches != 2 {break}
                let scale = Double(sender.scale)/previousScale
                previousScale = Double(sender.scale)
                cppTranslateZ(cppObject,gainFactor*transZFactor*(1-scale))
                let time = Date().timeIntervalSince(startTime!)
                log_transZ(time-time_stop, gainFactor*transZFactor*(1-scale))
                break
            }
            previousScale = Double(sender.scale)
            break
        case InteractionMode.BinaryPressure:
            switch sender.state {
            case UIGestureRecognizerState.began:
                if sender.numberOfTouches != 2 {break}
                _gestureDetected = true
                previousScale = 1.0
                break
            case UIGestureRecognizerState.ended:
                _gestureDetected = false
                break
            default:
                if sender.numberOfTouches != 2 {break}
                if isLightTouch == TouchMode.light {
                    let scale = Double(sender.scale)/previousScale
                    cppTranslateZ(cppObject,gainFactor*transZFactor*(1-scale))
                    let time = Date().timeIntervalSince(startTime!)
                    log_transZ(time-time_stop, gainFactor*transZFactor*(1-scale))
                }
                previousScale = Double(sender.scale)
                break
            }
            break
        default:
            break
        }
    }
    
    @IBAction func rotationDetected(_ sender: ForceRotationGestureRecognizer) {
        if !manipIsActive { return }
        switch interMode {
        case InteractionMode.noPressure:
            switch sender.state {
            case UIGestureRecognizerState.began:
                if sender.numberOfTouches != 2 {break}
                _gestureDetected = true
                previousRotateZ = 0.0
                break
            case UIGestureRecognizerState.ended:
                _gestureDetected = false
                break
            default:
                if sender.numberOfTouches != 2 {break}
                let angle = Double(sender.rotation) - previousRotateZ
                previousRotateZ = Double(sender.rotation)
                cppRotateZ(cppObject, gainFactor*rotZFactor*angle)
                let time = Date().timeIntervalSince(startTime!)
                log_rotateZ(time-time_stop, gainFactor*rotZFactor*angle)
                break
            }
            previousRotateZ = Double(sender.rotation)
            break
        case InteractionMode.BinaryPressure:
            switch sender.state {
            case UIGestureRecognizerState.began:
                if sender.numberOfTouches != 2 {break}
                _gestureDetected = true
                previousRotateZ = 0.0
                break
            case UIGestureRecognizerState.ended:
                _gestureDetected = false
                break
            default:
                if sender.numberOfTouches != 2 {break}
                if isLightTouch == TouchMode.oneHard{
                    let angle = Double(sender.rotation) - previousRotateZ
                    cppRotateZ(cppObject, gainFactor*rotZFactor*angle)
                    let time = Date().timeIntervalSince(startTime!)
                    log_rotateZ(time-time_stop, gainFactor*rotZFactor*angle)
                }
                previousRotateZ = Double(sender.rotation)
                break
            }
            break
        default:
            break
        }
    }
    
    @IBAction func panTwoDetected(_ sender: ForcePanGestureRecognizer) {
        if !manipIsActive { return }

        switch interMode {
        case InteractionMode.noPressure:
            switch sender.state {
            case UIGestureRecognizerState.began:
                if sender.numberOfTouches != 2 {break}
                _gestureDetected = true
                previousPanposX1 = Double(sender.location(ofTouch: 0, in: view).x)
                previousPanposX2 = Double(sender.location(ofTouch: 1, in: view).x)
                previousPanposY1 = Double(sender.location(ofTouch: 0, in: view).y)
                previousPanposY2 = Double(sender.location(ofTouch: 1, in: view).y)
                break
            case UIGestureRecognizerState.ended:
                _gestureDetected = false
                break
            default:
                if sender.numberOfTouches != 2 {break}
                let dx1 = Double(sender.location(ofTouch: 0, in: view).x) - previousPanposX1
                let dx2 = Double(sender.location(ofTouch: 1, in: view).x) - previousPanposX2
                let dy1 = Double(sender.location(ofTouch: 0, in: view).y) - previousPanposY1
                let dy2 = Double(sender.location(ofTouch: 1, in: view).y) - previousPanposY2
                
                previousPanposX1 = Double(sender.location(ofTouch: 0, in: view).x)
                previousPanposX2 = Double(sender.location(ofTouch: 1, in: view).x)
                previousPanposY1 = Double(sender.location(ofTouch: 0, in: view).y)
                previousPanposY2 = Double(sender.location(ofTouch: 1, in: view).y)
                
                let dx:Double
                if (dx1>0 && dx2<0) || (dx1<0 && dx2>0) || dx1==0 || dx2==0 {
                    dx = 0.0
                }else{
                    dx = (dx1>0) ? min(dx1,dx2) : max(dx1,dx2)
                }
                let dy:Double
                if (dy1>0 && dy2<0) || (dy1<0 && dy2>0) || dy1==0 || dy2==0 {
                    dy = 0.0
                }else{
                    dy = (dy1>0) ? min(dy1,dy2) : max(dy1,dy2)
                }
                
                if(dx > transThres || dx < -transThres){
                    cppTranslateX(cppObject,gainFactor*transXFactor*dx)
                    let time = Date().timeIntervalSince(startTime!)
                    log_transX(time-time_stop, gainFactor*transXFactor*dx)
                }
                if(dy > transThres || dy < -transThres){
                    cppTranslateY(cppObject,gainFactor*transYFactor*dy)
                    let time = Date().timeIntervalSince(startTime!)
                    log_transY(time-time_stop, gainFactor*transYFactor*dy)
                }
                break
            }
            break
        default:
            break
        }
    }
    
    func counter(){
        if timer.isValid {
            timer.invalidate()
        }
    }
    func showAlertButtonTapped(_ title: String, _ text: String) {
        
        // create the alert
        let alert = UIAlertController(title: title, message: text, preferredStyle: UIAlertControllerStyle.alert)
        
        // add an action (button)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        
        // show the alert
        self.present(alert, animated: true, completion: nil)
    }


}

