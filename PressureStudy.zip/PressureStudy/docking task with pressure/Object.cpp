

#include "Object.hpp"

Object::Object(const std::string& filename){
    projMatrix = Matrix4::perspective(2*M_PI/3, float(SCREEN_WIDTH)/SCREEN_HEIGHT, 10.0f, 1500.0f);
    projMatrix[1][1] *= -1;
    projMatrix[2][2] *= -1;
    projMatrix[2][3] *= -1;
    modelViewMatrix = Matrix4::identity();
    modelViewMatrix.setScale(3.0, 3.0, 3.0);
    center = Vector3(0.0, 0.0, 0.0);
    zooming = 0.5f;
    pProjMatrix = projMatrix;
    pModelViewMatrix = modelViewMatrix;
    pCenter = center;
    pzooming = zooming;
    
    tprojMatrix = Matrix4::perspective(2*M_PI/3, float(SCREEN_WIDTH)/SCREEN_HEIGHT, 10.0f, 1500.0f);
    tprojMatrix[1][1] *= -1;
    tprojMatrix[2][2] *= -1;
    tprojMatrix[2][3] *= -1;
    tmodelViewMatrix = Matrix4::identity();
    tmodelViewMatrix.setScale(3.0, 3.0, 3.0);
    tcenter = Vector3(0.0, 0.0, 0.0);
    
    data = LoaderOBJ::load(filename);
    target = LoaderOBJ::load(filename);
}

Object::~Object(){
}


void Object::setObj(double xTrans,double yTrans, double zTrans, double x, double y, double z, double w){
    
    xTrans = xTrans/double(SCREEN_WIDTH);
    yTrans = yTrans/double(SCREEN_HEIGHT);
    
    modelViewMatrix = (Quaternion(x,y,z,w).normalize()).rotationMatrix() * Matrix4::identity();
    modelViewMatrix = Matrix4(zoomingFactor, 0.0, 0.0, 0.0,
                               0.0, zoomingFactor, 0.0, 0.0,
                               0.0, 0.0, zoomingFactor, 0.0,
                               0.0, 0.0, 0.0, 1.0)
    * modelViewMatrix;
    modelViewMatrix = Matrix4(1.0, 0.0, 0.0, xTrans,
                              0.0, 1.0, 0.0, yTrans,
                              0.0, 0.0, 1.0, zTrans,
                              0.0, 0.0, 0.0, 1.0)
    * modelViewMatrix;
    
    center = Vector3(xTrans, yTrans, zTrans);
    pModelViewMatrix = modelViewMatrix;
    pCenter = center;
}

void Object::setTarget(double xTrans,double yTrans, double zTrans, double x, double y, double z, double w){
   
    xTrans = xTrans/double(SCREEN_WIDTH);
    yTrans = yTrans/double(SCREEN_HEIGHT);
    tmodelViewMatrix = (Quaternion(x,y,z,w).normalize()).rotationMatrix() * Matrix4::identity();
    tmodelViewMatrix = Matrix4(zoomingFactor, 0.0, 0.0, 0.0,
                               0.0, zoomingFactor, 0.0, 0.0,
                               0.0, 0.0, zoomingFactor, 0.0,
                               0.0, 0.0, 0.0, 1.0)
    * tmodelViewMatrix;
    tmodelViewMatrix = Matrix4(1.0, 0.0, 0.0, xTrans,
                              0.0, 1.0, 0.0, yTrans,
                              0.0, 0.0, 1.0, zTrans,
                              0.0, 0.0, 0.0, 1.0)
    * tmodelViewMatrix;
    tcenter = Vector3(xTrans, yTrans, zTrans);

}


void Object::rebind(){
    data->bind();
    target->bind();
}

void Object::render(){
    glDepthMask(true);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glDisable(GL_CULL_FACE);
    
    data->render(projMatrix, modelViewMatrix);
    target->renderTarget(tprojMatrix,tmodelViewMatrix);
}

void Object::rotateX(double x, double y, double z, double w){
    modelViewMatrix = Matrix4(1.0, 0.0, 0.0, center.x,
                              0.0, 1.0, 0.0, center.y,
                              0.0, 0.0, 1.0, center.z,
                              0.0, 0.0, 0.0, 1.0)
    * (Quaternion(x,y,z,w).rotationMatrix()
       * (Matrix4(1.0, 0.0, 0.0, -center.x,
                  0.0, 1.0, 0.0, -center.y,
                  0.0, 0.0, 1.0, -center.z,
                  0.0, 0.0, 0.0, 1.0)
          * modelViewMatrix));
}

void Object::rotateY(double x, double y, double z, double w){
    modelViewMatrix = Matrix4(1.0, 0.0, 0.0, center.x,
                              0.0, 1.0, 0.0, center.y,
                              0.0, 0.0, 1.0, center.z,
                              0.0, 0.0, 0.0, 1.0)
    * (Quaternion(x,y,z,w).rotationMatrix()
       * (Matrix4(1.0, 0.0, 0.0, -center.x,
                  0.0, 1.0, 0.0, -center.y,
                  0.0, 0.0, 1.0, -center.z,
                  0.0, 0.0, 0.0, 1.0)
          * modelViewMatrix));
}

void Object::rotateZ(double var){
    modelViewMatrix = Matrix4(1.0, 0.0, 0.0, center.x,
                              0.0, 1.0, 0.0, center.y,
                              0.0, 0.0, 1.0, center.z,
                              0.0, 0.0, 0.0, 1.0)
    * (Matrix4(cos(var), -sin(var), 0.0, 0.0,
               sin(var), cos(var), 0.0, 0.0,
               0.0, 0.0, 1.0, 0.0,
               0.0, 0.0, 0.0, 1.0)
       * (Matrix4(1.0, 0.0, 0.0, -center.x,
                  0.0, 1.0, 0.0, -center.y,
                  0.0, 0.0, 1.0, -center.z,
                  0.0, 0.0, 0.0, 1.0)
          * modelViewMatrix));
}


void Object::translateX(double var){
    var /= SCREEN_WIDTH;
    modelViewMatrix = Matrix4(1.0, 0.0, 0.0, var,
                              0.0, 1.0, 0.0, 0.0,
                              0.0, 0.0, 1.0, 0.0,
                              0.0, 0.0, 0.0, 1.0)
    * modelViewMatrix;
    center += Vector3(var, 0.0, 0.0);
}

void Object::translateY(double var){
    var /= SCREEN_HEIGHT;
    modelViewMatrix = Matrix4(1.0, 0.0, 0.0, 0.0,
                              0.0, 1.0, 0.0, var,
                              0.0, 0.0, 1.0, 0.0,
                              0.0, 0.0, 0.0, 1.0)
    * modelViewMatrix;
    center += Vector3(0.0, var, 0.0);
}

void Object::translateZ(double var){
    modelViewMatrix = Matrix4(1.0, 0.0, 0.0, 0.0,
                              0.0, 1.0, 0.0, 0.0,
                              0.0, 0.0, 1.0, var,
                              0.0, 0.0, 0.0, 1.0)
    * modelViewMatrix;
    center += Vector3(0.0, 0.0, var);
}

void Object::scale(double var){
    modelViewMatrix = Matrix4(1.0, 0.0, 0.0, center.x,
                              0.0, 1.0, 0.0, center.y,
                              0.0, 0.0, 1.0, center.z,
                              0.0, 0.0, 0.0, 1.0) *
    Matrix4(var, 0.0, 0.0, 0.0,
            0.0, var, 0.0, 0.0,
            0.0, 0.0, var, 0.0,
            0.0, 0.0, 0.0, 1.0) *
    Matrix4(1.0, 0.0, 0.0, -center.x,
            0.0, 1.0, 0.0, -center.y,
            0.0, 0.0, 1.0, -center.z,
            0.0, 0.0, 0.0, 1.0)
    * modelViewMatrix;
}


void Object::reset(){
    
}


void Object::recordView(){
    pProjMatrix = projMatrix;
    pModelViewMatrix = modelViewMatrix;
    pCenter = center;
    pzooming = zooming;

}

void Object::recallView(){
    projMatrix = pProjMatrix;
    modelViewMatrix = pModelViewMatrix;
    center = pCenter;
    zooming = pzooming;
}



