
import UIKit

class MenuVC: UIViewController {
    
    private var start:Date? = nil
    
    @IBOutlet weak var closeButton: UIButton!
    @IBAction func closeButtonUpInside(_ sender: Any) {
        manipIsActive = true
        let time = Date().timeIntervalSince(start!)
        time_stop += time
        dismiss(animated: true, completion: nil)
    }

    @IBOutlet weak var InterModeText: UILabel!
    @IBOutlet weak var trainButton: UIButton!
    @IBAction func trainButtonUpInside(_ sender: Any) {
        isTrainning = false
        gainFactor = 1.0
        trainButton.isHidden = true
    }
    
    
    @IBOutlet weak var pressureSlider: UISlider!
    @IBAction func pressureSliderUpInside(_ sender: UISlider) {
        switch interMode {
        case InteractionMode.BinaryPressure:
            forceThreshold = CGFloat(sender.value*20/3)
            break
        default:
            break
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        manipIsActive = false
        start = Date()
        if !isTrainning {
            trainButton.isHidden = true
        }
        
        switch interMode {
        case InteractionMode.noPressure:
            pressureSlider.isHidden = true
            InterModeText.text = "No pressure."
            break
        case InteractionMode.BinaryPressure:
            pressureSlider.value = Float(forceThreshold*3/20)
            InterModeText.text = "Real pressure."
            break
        default:
            break
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
