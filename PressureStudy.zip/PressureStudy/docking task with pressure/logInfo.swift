

import Foundation
import GLKit


//global data


enum InteractionMode {
    case noPressure
    case BinaryPressure
    case other
}

enum TouchMode {
    case no
    case light
    case oneHard
    case other
}


var interMode = InteractionMode.BinaryPressure

var forceThreshold: CGFloat = 3.0
var radiusThreshold: CGFloat = 50.0

var manipIsActive = true
var isTrainning = true
let trainIndex = 0

let transThres:Double = 0.2
var gainFactor:Double = 1.0
let transXFactor:Double = 30.0
let transYFactor:Double = 20.0
let transZFactor:Double = 200.0
let rotZFactor:Double = 2.0


//log
var USERID = ""

var train_index: Int = 0

let trial_tech:Int = 2
let trial_max: Int = 36
let trial_gain: Int = 12
var trial_number: Int = 0
var trial_touchdata = ""
var trial_objectdata = ""
var trial_finaldata = ""

var trial_data = obj_data[0]
var ptrial_data = obj_data[0]
var trial_target = target_data[0]

var time_stop = 0.0

var firstMode = InteractionMode.BinaryPressure
var secondMode = InteractionMode.noPressure
var trial_list = [1,2,3,4,5,6,7,8,9,10,11,12]
var trial_gainFactor:[Double] = [0.5, 1.0, 2.0]



func selectSetting(_ i : Int) {
    if i <= 0 {
        return
    }
    if i > 6 && i <= 18 {
        firstMode = InteractionMode.noPressure
        secondMode = InteractionMode.BinaryPressure
    }
    let j = i-1
    let list = [
    [1,2,3,4,5,6,7,8,9,10,11,12],
    [2,3,4,5,6,7,8,9,10,11,12,1],
    [3,4,5,6,7,8,9,10,11,12,1,2],
    [4,5,6,7,8,9,10,11,12,1,2,3],
    [5,6,7,8,9,10,11,12,1,2,3,4],
    [6,7,8,9,10,11,12,1,2,3,4,5],
    [7,8,9,10,11,12,1,2,3,4,5,6],
    [8,9,10,11,12,1,2,3,4,5,6,7],
    [9,10,11,12,1,2,3,4,5,6,7,8],
    [10,11,12,1,2,3,4,5,6,7,8,9],
    [11,12,1,2,3,4,5,6,7,8,9,10],
    [12,1,2,3,4,5,6,7,8,9,10,11]]
    trial_list = list[j%12]
    
    let list2 =
        [[0.5, 1.0, 2.0],
         [0.5, 2.0, 1.0],
         [1.0, 0.5, 2.0],
         [1.0, 2.0, 0.5],
         [2.0, 0.5, 1.0],
         [2.0, 1.0, 0.5]]
    trial_gainFactor = list2[j%6]
    
}


func log_reset(_ i: Int){
    
    trial_data = obj_data[i]
    ptrial_data = trial_data
    trial_target = target_data[i]
    time_stop = 0.0
    
    trial_touchdata = ("User ID," + USERID + "\n")
    trial_touchdata.append("Trial number," + String(trial_number) + "\n")
    trial_touchdata.append("Interaction mode," + String(describing: interMode) + "\n")
    
    trial_objectdata = ("User ID," + USERID + "\n")
    trial_objectdata.append("Trial number," + String(trial_number) + "\n")
    trial_objectdata.append("Interaction mode," + String(describing: interMode) + "\n")
    trial_objectdata.append("Gain factor, \(gainFactor) \n")
trial_objectdata.append("TargetTransX,TargetTransY,TargetTransZ,TargetRotX,TargetRotY,TargetRotZ,TargetRotw\n")
    trial_objectdata.append(String(trial_target[0]) + ",")
    trial_objectdata.append(String(trial_target[1]) + ",")
    trial_objectdata.append(String(trial_target[2]) + ",")
    trial_objectdata.append(String(trial_target[3]) + ",")
    trial_objectdata.append(String(trial_target[4]) + ",")
    trial_objectdata.append(String(trial_target[5]) + ",")
    trial_objectdata.append(String(trial_target[6]) + "\n")

    trial_objectdata.append("Time,Action,PosX,PosY,PosZ,OriX,OriY,OriZ,OriW,Distance,Angle,DistancePre,AnglePre\n")
    trial_objectdata.append("0,IDLE,") //time + mode
    log_compute()
    trial_objectdata.append("0,0 \n") //predis + preang

}

func log_record(_ time:TimeInterval){
    ptrial_data = trial_data
    trial_objectdata.append("\(time),record,") //time + mode
    log_compute()
    trial_objectdata.append("0,0 \n") //predis + preang
}

func log_recall(_ time:TimeInterval){
    trial_data = ptrial_data
    trial_objectdata.append("\(time),recall,") //time + mode
    log_compute()
    trial_objectdata.append("0,0 \n") //predis + preang
}

func log_transX(_ time:TimeInterval, _ dis:Double){
    trial_data[0] += dis
    trial_objectdata.append("\(time),TranslationX,") //time + mode
    log_compute()
    trial_objectdata.append("\(dis),0 \n") //predis + preang
}

func log_transY(_ time:TimeInterval, _ dis:Double){
    trial_data[1] += dis
    trial_objectdata.append("\(time),TranslationY,") //time + mode
    log_compute()
    trial_objectdata.append("\(dis),0 \n") //predis + preang
}

func log_transZ(_ time:TimeInterval, _ dis:Double){
    trial_data[2] += dis
    trial_objectdata.append("\(time),TranslationZ,") //time + mode
    log_compute()
    trial_objectdata.append("\(dis),0 \n") //predis + preang
}


func log_rotateX(_ time:TimeInterval, _ angle:[Double]){
    let v2 = [trial_data[3], trial_data[4], trial_data[5], trial_data[6]]
    let v1 = angle
    var n = [0.0, 0.0, 0.0, 0.0]
    n[0] = v1[3]*v2[0] + v1[0]*v2[3] + v1[1]*v2[2] - v1[2]*v2[1]
    n[1] = v1[3]*v2[1] + v1[1]*v2[3] + v1[2]*v2[0] - v1[0]*v2[2]
    n[2] = v1[3]*v2[2] + v1[2]*v2[3] + v1[0]*v2[1] - v1[1]*v2[0]
    n[3] = v1[3]*v2[3] - v1[0]*v2[0] - v1[1]*v2[1] - v1[2]*v2[2]
    trial_data[3] = n[0]
    trial_data[4] = n[1]
    trial_data[5] = n[2]
    trial_data[6] = n[3]
    trial_objectdata.append("\(time),RotationX,") //time + mode
    log_compute()
    trial_objectdata.append("0,0\n") //predis + preang
}

func log_rotateY(_ time:TimeInterval, _ angle:[Double]){
    let v2 = [trial_data[3], trial_data[4], trial_data[5], trial_data[6]]
    let v1 = angle
    var n = [0.0, 0.0, 0.0, 0.0]
    n[0] = v1[3]*v2[0] + v1[0]*v2[3] + v1[1]*v2[2] - v1[2]*v2[1]
    n[1] = v1[3]*v2[1] + v1[1]*v2[3] + v1[2]*v2[0] - v1[0]*v2[2]
    n[2] = v1[3]*v2[2] + v1[2]*v2[3] + v1[0]*v2[1] - v1[1]*v2[0]
    n[3] = v1[3]*v2[3] - v1[0]*v2[0] - v1[1]*v2[1] - v1[2]*v2[2]
    trial_data[3] = n[0]
    trial_data[4] = n[1]
    trial_data[5] = n[2]
    trial_data[6] = n[3]
    trial_objectdata.append("\(time),RotationY,") //time + mode
    log_compute()
    trial_objectdata.append("0,0 \n") //predis + preang
}

func log_rotateZ(_ time:TimeInterval, _ angle:Double){
    let v2 = [trial_data[3], trial_data[4], trial_data[5], trial_data[6]]
    let v1 = rotZAngle(angle)
    var n = [0.0, 0.0, 0.0, 0.0]
    n[0] = v1[3]*v2[0] + v1[0]*v2[3] + v1[1]*v2[2] - v1[2]*v2[1]
    n[1] = v1[3]*v2[1] + v1[1]*v2[3] + v1[2]*v2[0] - v1[0]*v2[2]
    n[2] = v1[3]*v2[2] + v1[2]*v2[3] + v1[0]*v2[1] - v1[1]*v2[0]
    n[3] = v1[3]*v2[3] - v1[0]*v2[0] - v1[1]*v2[1] - v1[2]*v2[2]
    trial_data[3] = n[0]
    trial_data[4] = n[1]
    trial_data[5] = n[2]
    trial_data[6] = n[3]
    trial_objectdata.append("\(time),RotationZ,") //time + mode
    log_compute()
    trial_objectdata.append("0,\(angle) \n") //predis + preang
}

func log_compute(){
    trial_objectdata.append("\(trial_data[0]),") //posX
    trial_objectdata.append("\(trial_data[1]),") //posY
    trial_objectdata.append("\(trial_data[2]),") //posZ
    trial_objectdata.append("\(trial_data[3]),") //oriX
    trial_objectdata.append("\(trial_data[4]),") //oriY
    trial_objectdata.append("\(trial_data[5]),") //oriZ
    trial_objectdata.append("\(trial_data[6]),") //oriW
    trial_objectdata.append("\(compute_distance()),\(compute_angle()),") //Dis / ang
}


func compute_distance()->Double{
    let x = trial_target[0]-trial_data[0]
    let y = trial_target[1]-trial_data[1]
    let z = trial_target[2]-trial_data[2]
    return sqrt(x*x+y*y+z*z)
}
func compute_angle()->Double{
    let old = [trial_data[3], trial_data[4], trial_data[5], trial_data[6]]
    let squadLength = old[0]*old[0] + old[1]*old[1] + old[2]*old[2] + old[3]*old[3]
    let inverse = [-old[0]/squadLength, -old[1]/squadLength, -old[2]/squadLength, old[3]/squadLength]
    var n = [0.0, 0.0, 0.0, 0.0]
    n[0] = inverse[3]*trial_target[3] + inverse[0]*trial_target[6] + inverse[1]*trial_target[5] - inverse[2]*trial_target[4]
    n[1] = inverse[3]*trial_target[4] + inverse[1]*trial_target[6] + inverse[2]*trial_target[3] - inverse[0]*trial_target[5]
    n[2] = inverse[3]*trial_target[5] + inverse[2]*trial_target[6] + inverse[0]*trial_target[4] - inverse[1]*trial_target[3]
    n[3] = inverse[3]*trial_target[6] - inverse[0]*trial_target[3] - inverse[1]*trial_target[4] - inverse[2]*trial_target[5]
    if n[3] < 0.0 { n[3] *= -1.0 }
    if n[3] > 1 { n[3] = 1 }
    let angle = 2 * acos(n[3])
    return angle * 180/3.14159
}



func saveFile(){
    //save data to file
    let touchFile = USERID + "_" + String(describing: interMode) + String(trial_number) + "_touch.csv"
    var touchPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
    touchPath.appendPathComponent(touchFile)
    let objFile = USERID + "_" + String(describing: interMode) + String(trial_number) + "_obj.csv"
    var objPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
    objPath.appendPathComponent(objFile)
    do {
        //try trial_touchdata.write(to: touchPath, atomically: true, encoding: String.Encoding.utf8)
        try trial_objectdata.write(to: objPath, atomically: true, encoding: String.Encoding.utf8)
    } catch {
        print("Failed to create file")
        print("\(error)")
    }
}

func saveFinal(){
    //save data to file
    let file = USERID + "_" + "_results.csv"
    var path = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
    path.appendPathComponent(file)
    do {
        try trial_finaldata.write(to: path, atomically: true, encoding: String.Encoding.utf8)
    } catch {
        print("Failed to create file")
        print("\(error)")
    }
}




