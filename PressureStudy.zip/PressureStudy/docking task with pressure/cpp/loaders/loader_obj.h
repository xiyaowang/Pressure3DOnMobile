#ifndef LOADER_OBJ_H
#define LOADER_OBJ_H

#include "global.h"

namespace LoaderOBJ
{
	MeshPtr load(const std::string& fileName);
}

#endif /* LOADER_OBJ_H */
