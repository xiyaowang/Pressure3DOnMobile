#ifndef LOADER_PLY_H
#define LOADER_PLY_H

#include "global.h"

namespace LoaderPLY
{
	MeshPtr load(const std::string& fileName);
}

#endif /* LOADER_PLY_H */
