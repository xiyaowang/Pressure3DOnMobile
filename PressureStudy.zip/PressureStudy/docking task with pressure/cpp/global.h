#ifndef GLOBAL_H
#define GLOBAL_H

#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <memory>
#include <utility>
#include <stdexcept>


#define LOGD(...) (printf(__VA_ARGS__), printf("\n"))
#define LOGI(...) (printf(__VA_ARGS__), printf("\n"))
#define LOGW(...) (fprintf(stderr, __VA_ARGS__), fprintf(stderr, "\n"))
#define LOGE(...) (fprintf(stderr, __VA_ARGS__), fprintf(stderr, "\n"))


// #define DOUBLE_PRECISION
#include "util/linear_math.h"

#include "util/synchronized.h"
#include "util/utility.h"

#define GL_GLEXT_PROTOTYPES
#include <OpenGLES/ES3/gl.h>
#include <OpenGLES/ES3/glext.h>

#include "fwd.h"

#endif /* GLOBAL_H */
