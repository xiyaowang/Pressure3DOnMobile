

#include "ObjectBridge.h"
#include "Object.hpp"

const void* createObj(const char* filename){
    Object* obj = new Object(filename);
    return (void*) obj;
}

void objSetObj(const void *obj, double xTrans,double yTrans, double zTrans, double x, double y, double z, double w){
    Object* o = (Object*) obj;
    o->setObj(xTrans, yTrans, zTrans, x, y, z, w);
}

void objSetTarget(const void *obj, double xTrans,double yTrans, double zTrans, double x, double y, double z, double w){
    Object* o = (Object*) obj;
    o->setTarget(xTrans, yTrans, zTrans, x, y, z, w);
}

void objRebind(const void *obj){
    Object* o = (Object*) obj;
    o->rebind();
}

void objRender(const void *obj){
    Object* o = (Object*) obj;
    o->render();
}

void cppRotateX(const void *object, double x, double y, double z, double w){
    Object *o = (Object*) object;
    o->rotateX(x,y,z,w);
}

void cppRotateY(const void *object, double x, double y, double z, double w){
    Object *o = (Object*) object;
    o->rotateY(x,y,z,w);
}

void cppRotateZ(const void *object, double var){
    Object *o = (Object*) object;
    o->rotateZ(var);
}

void cppTranslateX(const void *object, double var){
    Object *o = (Object*) object;
    o->translateX(var);
}

void cppTranslateY(const void *object, double var){
    Object *o = (Object*) object;
    o->translateY(var);
}

void cppTranslateZ(const void *object, double var){
    Object *o = (Object*) object;
    o->translateZ(var);
}

void cppScale(const void *object, double var){
    Object *o = (Object*) object;
    //o->scale(var);
    o->translateZ(var);
}

void objReset(const void *object){
    Object *o = (Object*) object;
    o->reset();
}

void objRecord(const void *object){
    Object *o = (Object*) object;
    o->recordView();
}

void objRecall(const void *object){
    Object *o = (Object*) object;
    o->recallView();
}
























