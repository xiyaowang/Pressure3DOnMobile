

#ifndef ObjectBridge_h
#define ObjectBridge_h

#ifdef __cplusplus
extern "C" {
#endif

    const void* createObj(const char* filename);
    
    void objSetObj(const void *obj, double xTrans,double yTrans, double zTrans, double x, double y, double z, double w);
    void objSetTarget(const void *obj, double xTrans,double yTrans, double zTrans, double x, double y, double z, double w);
    
    void objRebind(const void *obj);
    void objRender(const void *obj);

    void cppRotateX(const void *object, double x, double y, double z, double w);
    void cppRotateY(const void *object, double x, double y, double z, double w);
    void cppRotateZ(const void *object, double var);
    
    void cppTranslateX(const void *object, double var);
    void cppTranslateY(const void *object, double var);
    void cppTranslateZ(const void *object, double var);

    void cppScale(const void *object, double var);
    
    void objReset(const void *object);
    void objRecord(const void *object);
    void objRecall(const void *object);
    
    
    
    
#ifdef __cplusplus
}
#endif

#endif /* ObjectBridge_h */
