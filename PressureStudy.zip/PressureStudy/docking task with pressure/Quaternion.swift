

import Foundation

func constraintXAngle( _ current:Double, _ previous:Double, _ height:Double) -> [Double] {
    var res = [0.0, 0.0, 0.0, 0.0]
    
    var OP1 = [0.0, (4*previous/height - 1), 0.0];
    var r = OP1[1]*OP1[1]
    if r>1 {
        OP1[1] = OP1[1]/sqrt(r)
    }else{
        OP1[2] = -sqrt(1-r)
    }
    
    var OP2 = [0.0, (4*current/height - 1), 0.0];
    r = OP2[1]*OP2[1]
    if r>1 {
        OP2[1] = OP2[1]/sqrt(r)
    }else{
        OP2[2] = -sqrt(1-r)
    }
    res[0] = OP1[1]*OP2[2] - OP1[2]*OP2[1]
    res[1] = OP1[2]*OP2[0] - OP1[0]*OP2[2]
    res[2] = OP1[0]*OP2[1] - OP1[1]*OP2[0]
    res[3] = OP1[1]*OP2[1] + OP1[2]*OP2[2]
    /*let s = sqrt(1 - res[3]*res[3])
    let ss = sqrt(res[0]*res[0] + res[1]*res[1] + res[2]*res[2])
    res[0] = res[0]*s/ss
    res[1] = res[1]*s/ss
    res[2] = res[2]*s/ss*/
    let s = sin(acos(res[3]))
    res[0] = res[0]*s
    res[1] = res[1]*s
    res[2] = res[2]*s
    return res
}

func constraintYAngle(_ current:Double, _ previous:Double, _ width:Double) -> [Double] {
    var res = [0.0, 0.0, 0.0, 0.0]
    var OP1 = [(4*previous/width - 1), 0.0, 0.0];
    let r = OP1[0]*OP1[0]
    if r>1 {
        OP1[0] = OP1[0]/sqrt(r)
    }else{
        OP1[2] = -sqrt(1-r)
    }
    
    var OP2 = [4*current/width - 1, 0.0, 0.0];
    let r2 = OP2[0]*OP2[0]
    if r>1 {
        OP2[0] = OP2[0]/sqrt(r2)
    }else{
        OP2[2] = -sqrt(1-r2)
    }
    
    res[0] = OP1[1]*OP2[2] - OP1[2]*OP2[1]
    res[1] = OP1[2]*OP2[0] - OP1[0]*OP2[2]
    res[2] = OP1[0]*OP2[1] - OP1[1]*OP2[0]
    res[3] = OP1[0]*OP2[0] + OP1[2]*OP2[2]
    /*let s = sqrt(1 - res[3]*res[3])
    let ss = sqrt(res[0]*res[0] + res[1]*res[1] + res[2]*res[2])
    res[0] = res[0]*s/ss
    res[1] = res[1]*s/ss
    res[2] = res[2]*s/ss*/
    let s = sin(acos(res[3]))
    res[0] = res[0]*s
    res[1] = res[1]*s
    res[2] = res[2]*s
    return res

    }


func rotXAngle(_ diff:Double, _ height:Double) -> [Double] {
    let angle = 3.14*diff/height
    return [sin(angle/2), 0.0, 0.0, cos(angle/2)]
}

func rotYAngle(_ diff:Double, _ width:Double) -> [Double] {
    let angle = 3.14*diff/width
    return [0.0, sin(angle/2), 0.0, cos(angle/2)]
}

func rotZAngle(_ angle:Double) -> [Double] {
    return [0.0, 0.0, sin(angle/2), cos(angle/2)]
}



//http://www.cg.info.hiroshima-cu.ac.jp/~miyazaki/knowledge/teche52.html
func SIGN(_ x:Double)->Double{
    return (x >= 0.0) ? +1.0 : -1.0
}

func NORM(_ a:Double, _ b:Double, _ c:Double, _ d:Double)->Double{
    return sqrt(a * a + b * b + c * c + d * d)
}

func MatToQuaternion(_ m:[[Double]])->[Double]{
    var q = [0.0, 0.0, 0.0, 0.0]
    q[0] = ( m[0][0] + m[1][1] + m[2][2] + 1.0) / 4.0
    q[1] = ( m[0][0] - m[1][1] - m[2][2] + 1.0) / 4.0
    q[2] = (-m[0][0] + m[1][1] - m[2][2] + 1.0) / 4.0
    q[3] = (-m[0][0] - m[1][1] + m[2][2] + 1.0) / 4.0
    
    if q[0] >= q[1] && q[0] >= q[2] && q[0] >= q[3] {
        q[0] *= +1.0;
        q[1] *= SIGN(m[2][1] - m[1][2])
        q[2] *= SIGN(m[0][2] - m[2][0])
        q[3] *= SIGN(m[1][0] - m[0][1])
    }else if q[1] >= q[0] && q[1] >= q[2] && q[1] >= q[3] {
        q[0] *= SIGN(m[2][1] - m[1][2])
        q[1] *= +1.0
        q[2] *= SIGN(m[1][0] + m[0][1])
        q[3] *= SIGN(m[0][2] + m[2][0])
    } else if q[2] >= q[0] && q[2] >= q[1] && q[2] >= q[3] {
        q[0] *= SIGN(m[0][2] - m[2][0])
        q[1] *= SIGN(m[1][0] + m[0][1])
        q[2] *= +1.0
        q[3] *= SIGN(m[2][1] + m[1][2])
    } else if q[3] >= q[0] && q[3] >= q[1] && q[3] >= q[2] {
        q[0] *= SIGN(m[1][0] - m[0][1])
        q[1] *= SIGN(m[2][0] + m[0][2])
        q[2] *= SIGN(m[2][1] + m[1][2])
        q[3] *= +1.0
    } else {
        print("coding error")
    }
    let r = NORM(q[0], q[1], q[2], q[3])
    q[0] /= r
    q[1] /= r
    q[2] /= r
    q[3] /= r
    return q
}


