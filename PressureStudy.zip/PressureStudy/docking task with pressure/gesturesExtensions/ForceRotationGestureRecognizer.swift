
import UIKit.UIGestureRecognizerSubclass

public class ForceRotationGestureRecognizer: UIRotationGestureRecognizer {
    public private(set) var forceMax: CGFloat = 0.0
    public private(set) var forceMin: CGFloat = 0.0
    
    convenience init() {
        self.init(target: nil, action: nil)
    }
    
    public override init(target: Any?, action: Selector?) {
        super.init(target: target, action: action)
        cancelsTouchesInView = false
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent) {
        super.touchesBegan(touches, with: event)
        ForceAndFireEvent(.began, touches: touches)
    }
    
    public override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent) {
        super.touchesMoved(touches, with: event)
        ForceAndFireEvent(.changed, touches: touches)
    }
    
    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent) {
        super.touchesEnded(touches, with: event)
        ForceAndFireEvent(.ended, touches: touches)
    }
    
    public override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent) {
        super.touchesCancelled(touches, with: event)
        ForceAndFireEvent(.cancelled, touches: touches)
    }
    
    private func ForceAndFireEvent(_ state: UIGestureRecognizerState, touches: Set<UITouch>) {
        //Putting a guard statement here to make sure we don't fire off our target's selector event if a touch doesn't exist to begin with.
        guard let firstTouch = touches.first else { return }
                
        if touches.count == 2 {
            let first = (touches as NSSet).allObjects[0] as! UITouch
            let second = (touches as NSSet).allObjects[1] as! UITouch
            if first.force >= second.force {
                forceMax = first.force
                forceMin = second.force
            }else{
                forceMin = first.force
                forceMax = second.force
            }
        }else{
            let first = (touches as NSSet).allObjects[0] as! UITouch
            forceMin = first.force
            forceMax = first.force
        }
        //self.state = state
    }
    
    public override func reset() {
        super.reset()
        forceMin = 0.0
        forceMax = 0.0
    }
}
